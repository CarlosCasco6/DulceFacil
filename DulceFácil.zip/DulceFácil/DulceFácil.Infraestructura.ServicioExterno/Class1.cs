﻿namespace DulceFácil.Infraestructura.ServicioExterno
{
    public class Class1
    {

    }
}
