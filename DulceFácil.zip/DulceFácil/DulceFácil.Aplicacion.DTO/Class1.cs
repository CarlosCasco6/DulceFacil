﻿namespace DulceFácil.Aplicacion.DTO
{
    public class Class1
    {

    }
}
