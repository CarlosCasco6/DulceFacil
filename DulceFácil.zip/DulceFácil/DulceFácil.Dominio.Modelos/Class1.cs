﻿namespace DulceFácil.Dominio.Modelos
{
    public class Class1
    {

    }
}
