﻿namespace DulceFácil.Infraestructura.ServicioEmail
{
    public class Class1
    {

    }
}
