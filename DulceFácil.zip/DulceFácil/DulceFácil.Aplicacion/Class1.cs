﻿namespace DulceFácil.Aplicacion
{
    public class Class1
    {

    }
}
