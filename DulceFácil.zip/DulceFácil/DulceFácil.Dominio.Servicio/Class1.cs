﻿namespace DulceFácil.Dominio.Servicio
{
    public class Class1
    {

    }
}
