﻿namespace DulceFácil.Infraestructura.CrossCuting
{
    public class Class1
    {

    }
}
