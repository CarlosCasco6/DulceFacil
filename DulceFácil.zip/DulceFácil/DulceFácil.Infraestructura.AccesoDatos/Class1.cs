﻿namespace DulceFácil.Infraestructura.AccesoDatos
{
    public class Class1
    {

    }
}
